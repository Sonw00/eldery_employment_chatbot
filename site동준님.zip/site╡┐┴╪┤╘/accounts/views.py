# C:\go\site\accounts\views.py
from django.contrib import auth
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib import auth
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib.auth import authenticate

from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.forms import AuthenticationForm  # 임포트
from .forms import SignupForm

def signup_view(request): 
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email'].strip()
            email_domain = form.cleaned_data['email_domain'].strip()
            password = form.cleaned_data['password1'].strip()
            address = form.cleaned_data['address'].strip()
            detailed_address = form.cleaned_data['detailed_address'].strip()
            business_type = form.cleaned_data['business_type'].strip()

            # 이메일 형식 처리: 선택된 도메인이 '직접 입력'이 아닌 경우
            if email_domain != 'custom':
                if '@' in email:  # 이메일 입력 필드에 '@'가 포함된 경우
                    form.add_error('email', "'@'는 이메일 입력란에 포함될 수 없습니다. 도메인을 선택하세요.")
                    return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})
                full_email = f"{email}{email_domain}"
            else:
                # '직접 입력'인 경우 '@' 포함 확인
                if '@' in email:
                    form.add_error('email', "'@'를 포함하지 않고 도메인 입력란에 입력하세요.")
                    return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})
                
                # 사용자로부터 입력받은 도메인
                custom_domain = form.cleaned_data.get('custom_domain', '').strip()
                if not custom_domain:
                    form.add_error('custom_domain', '도메인을 직접 입력해주세요.')
                    return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})
                full_email = f"{email}@{custom_domain}"

            # 이메일 유효성 검사 (간단한 '@' 포함 여부 검사)
            if '@' not in full_email and '.' not in full_email:
                form.add_error('email', '유효한 이메일 주소를 입력해주세요.')
                return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})

            # 사용자 생성 및 예외 처리
            try:
                user = User.objects.create_user(
                    username=full_email,
                    password=password,
                    email=full_email,
                )
                # 자동 로그인 처리
                auth_login(request, user)
                return redirect('home')
            except Exception as e:
                # 예외 발생 시 오류 메시지 표시
                form.add_error(None, f'회원가입 중 오류가 발생했습니다: {str(e)}')
                return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})
    else:
        form = SignupForm()
    
    return render(request, 'signup.html', {'form': form, 'kakao_api_key': settings.KAKAO_API_KEY})



def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)  # Django 내장 로그인 함수
            return redirect('home')  # 로그인 성공 시 홈으로 리디렉션
        else:
            return render(request, 'login.html', {'form': form})  # 실패 시 폼에 오류 표시
    else:
        form = AuthenticationForm()  # 빈 폼을 전달
    return render(request, 'login.html', {'form': form})

def logout(request):
    auth.logout(request)
    return redirect('home')

def home(request):
    return render(request, 'chatbot/home.html')
